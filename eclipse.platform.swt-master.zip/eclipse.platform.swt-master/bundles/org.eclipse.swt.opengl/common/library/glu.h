#ifdef __APPLE__
#include <OpenGL/glu.h>
#else
#ifdef WIN32
#include <windows.h>
#endif
#include <GL/glu.h>
#endif

extern int IS_JNI_1_2;
